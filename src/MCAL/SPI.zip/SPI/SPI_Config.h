/*
 * SPI_Config.h
 *
 *  Created on: Sep 17, 2023
 *      Author: WIN10
 */

#ifndef MCAL_SPI_SPI_CONFIG_H_
#define MCAL_SPI_SPI_CONFIG_H_





#endif /* MCAL_SPI_SPI_CONFIG_H_ */
